export const firebaseConfig = {
    apiKey: "AIzaSyABQqZLp0v6RkM-Qj-_tFlczFVDCR0zvbE",
    authDomain: "storytelling-app-60dbe.firebaseapp.com",
    projectId: "storytelling-app-60dbe",
    storageBucket: "storytelling-app-60dbe.appspot.com",
    messagingSenderId: "817600991173",
    appId: "1:817600991173:web:2656a4f561b0f1b74585ac"
  };